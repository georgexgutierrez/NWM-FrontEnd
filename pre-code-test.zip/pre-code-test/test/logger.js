const fs = require('fs'),
      yaml = require('js-yaml'),
      logger = require('../logger').logger;
	  LEVELS = require('../logger').LEVELS;
const chai = require('chai');
const expect = chai.expect;
chai.should();

describe('Logger transport file override Sync', function() {
	it('', function(){ 
		const file = `out/${LEVELS.DEBUG}.log`;
		// delete the debug.log if it exists
		// so we are only testing the one entry this test will put in
		try{
			fs.accessSync(file);
			fs.unlinkSync(file);
		}catch(ex){
			//eat it;
		}
		const fileLogger = new logger({
			transport(level, message) {
				fs.appendFileSync(`out/${level}.log`, message + '\n');
			}
		});
		fileLogger.log({cwd: __dirname}, LEVELS.DEBUG);
		const data = fs.readFileSync(file,'utf8');
		const logData = JSON.parse(data);
		expect(logData.message.cwd).to.equal(__dirname);
		expect(logData.level).to.equal(LEVELS.DEBUG);
	})
});

describe('Logger transport file override Async', function() {
	it('', function(){ 
		const file = `out/${LEVELS.DEBUG}.log`;
		// delete the debug.log if it exists
		// so we are only testing the one entry this test will put in
		try{
			fs.accessSync(file);
			fs.unlinkSync(file);
		}catch(ex){
			//eat it;
		}
		const fileLogger = new logger({
			transport(level, message) {
				fs.appendFile(`out/${level}.log`, message + '\n', function(){
							fs.readFile(file,'utf8',function(error,data){;
								const logData = JSON.parse(data);
								expect(logData.message.cwd).to.equal(__dirname);
								expect(logData.level).to.equal(LEVELS.DEBUG);
							});
				});
			}
		});
		fileLogger.log({cwd: __dirname}, LEVELS.DEBUG);
	})
});