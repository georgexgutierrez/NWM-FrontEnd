const LEVELS = {
    INFO: 'info',
    WARN: 'warning',
    ERROR: 'error',
    DEBUG: 'debug'
};

function logger(config) {
	this.root = 'root';
	// lets check first that something was passed in before using it
	// doing this because examples shows sometimes config passed in other times not
	// only use if it matches type
	if(config){
		if(config.root && typeof config.root === 'string'){
			this.root = config.root;
		}else{
			console.log("root not set missing or not a string");
		}
		if (config.format && (typeof config.format === 'function')) {
			this.format = config.format;
		}else{
			console.log("logger.format not overridden passed in object format property missing or not a function");
		}
		if (config.transport && (typeof config.transport === 'function')) {
			this.transport = config.transport;
		}else{
			console.log("logger.transport not overridden passed in object transport property missing or not a function");
		}
	}
}

logger.prototype = {

    log(data, level) {
        this.level = level;
        this.data = data;

        const logObj = this.createLogObject();

        const message = this.format(logObj);

        this.transport(level, message);
    },

    createLogObject() {
        let rootObj;
		// removed if check since our changes up above pretty much guarantees
		// this.root exists
        //if (this.root) {
            rootObj = { root: this.root };
        //}
		// since nothing guarantees that data passed in will be just a string or a object with message property
		// will check and return appropriate object
        const data = typeof this.data == 'string' ? { message: this.data } : this.data.message ? this.data : { message: this.data };

        const logObj = Object.assign(rootObj, data, { level: this.level || 'info'});

        return logObj;
    },

    format(logObj) {
        return JSON.stringify(logObj);
    },

    transport(level, message) {
        const chalk = require('chalk');

        if (level == 'error') {
            console.log(chalk.red(message));
        }
        else if (level == 'warning') {
            console.log(chalk.yellow(message));
        }
        else if (level == 'debug') {
            console.log(chalk.blue(message));
        }
        else {
            //the default is info
            console.log(chalk.green(message));
        }

    }
}

module.exports = { logger, LEVELS };